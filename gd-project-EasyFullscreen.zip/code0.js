gdjs.GameSceneCode = {};

gdjs.GameSceneCode.conditionTrue_0 = {val:false};
gdjs.GameSceneCode.condition0IsTrue_0 = {val:false};


gdjs.GameSceneCode.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtsExt__EasyFullscreen__EasyFullscreen.func(runtimeScene, "Num0", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};

gdjs.GameSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.GameSceneCode.eventsList0(runtimeScene);
return;

}

gdjs['GameSceneCode'] = gdjs.GameSceneCode;
